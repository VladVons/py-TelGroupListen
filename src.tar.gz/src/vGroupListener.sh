#!/bin/bash

python3 vGroupListener.py --task task_01.json
